package ui;

import Model.Controller;

import java.util.Scanner;

public class Main {

    public static Scanner sc;
    private Controller control;

    public Main() {
        this.control = new Controller();
        sc = new Scanner(System.in);
    }

    public static void main(String[] args) throws Exception {

        Main ppal = new Main();

        int option;
        ppal.showMenu();


    }

    public void showMenu() throws Exception {

        System.out.println("Welcome to starLab what you want to do?!\n");


        boolean stopFlag = false;

        while (!stopFlag) {
            System.out.println("MENU:\n");
            System.out.println("Select in:\n\n" + "(1) Found the way with minimum cost\n" + "(2) find  \n" + "possible ambushes\n" + "(3) find the way with minimun cost passing for all the planets" + "(0) Exit");
            int mainOption = sc.nextInt();
            System.out.println("Select in what method do you want to work:\n\n" + "(1) List\n" + "(2) Matrix\n");
            int method = sc.nextInt();

            switch (mainOption){
                case 1:
                    if (method==1){
                        control.applyDikstraL();

                    }else if(method==2){
                        control.applyDikstraM();
                    }
                    break;
                case 2:
                    System.out.println("put the vertex in that you are to do the scrach");
                    if (method==1){
                        control.appllyBFSL();

                    }else if(method==2){
                        control.appllyBFSM();
                    }

                    break;
                case 3:
                    if (method==1){

                        control.applyKruskal();

                    }else if(method==2){
                        control.applyKruskaM();
                    }

                    System.out.println("the way with a minor height is:");

                    break;
                case 0:
                    stopFlag=true;
                    break;

            }


        }
    }




}