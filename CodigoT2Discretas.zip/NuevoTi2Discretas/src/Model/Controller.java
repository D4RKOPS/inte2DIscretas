package Model;
import.Model.Graph
public class Controller {



    public void applyDikstraL(){



    }

    public void appllyBFSL(){


    }

    public void applyKruskal(){

    }

    public void applyDikstraM(){


    }

    public void appllyBFSM(){


    }

    public void applyKruskaM(){

    }


}
