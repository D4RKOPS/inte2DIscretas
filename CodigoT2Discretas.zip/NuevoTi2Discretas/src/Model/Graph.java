package Model;

import java.util.ArrayList;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.*;


public class Graph {

    private List nodes = new ArrayList();

    public void addNode(Node node) {

        nodes.add(node);

    }

    public List getNodes() {

        return nodes;

    }

    @Override

    public String toString() {

        return "Model.Graph [nodes=" + nodes + "]";

    }

    // create KruskalAlgorithm class to create minimum spanning tree of the given graph
    class KruskalAlgorithm {
        //create class Model.Edge to create an edge of the graph that implements Comparable interface
        class Edge implements Comparable<Edge> {
            int source, destination, weight;

            public int compareTo(Edge edgeToCompare) {
                return this.weight - edgeToCompare.weight;
            }
        }

        ;

        // create class Subset for union
        class Subset {
            int parent, value;
        }

        ;

        //initialize vertices, edges and edgeArray
        int vertices, edges;
        Edge edgeArray[];

        // using constructor to create a graph
        KruskalAlgorithm(int vertices, int edges) {
            this.vertices = vertices;
            this.edges = edges;
            edgeArray = new Edge[this.edges];
            for (int i = 0; i < edges; ++i)
                edgeArray[i] = new Edge();  //create edge for all te edges given by the user
        }

        // create applyKruskal() method for applying Kruskal's Algorithm
        void applyKruskal() {

            // initialize finalResult array to store the final MST
            Edge finalResult[] = new Edge[vertices];
            int newEdge = 0;
            int index = 0;
            for (index = 0; index < vertices; ++index)
                finalResult[index] = new Edge();

            // using sort() method for sorting the edges
            Arrays.sort(edgeArray);

            // create an array of the vertices of type Subset for the subsets of vertices
            Subset subsetArray[] = new Subset[vertices];

            // aloocate memory to create vertices subsets
            for (index = 0; index < vertices; ++index)
                subsetArray[index] = new Subset();

            // it is used to create subset with single element
            for (int vertex = 0; vertex < vertices; ++vertex) {
                subsetArray[vertex].parent = vertex;
                subsetArray[vertex].value = 0;
            }
            index = 0;

            // use for loop to pick the smallers edge from the edges and increment the index for next iteration
            while (newEdge < vertices - 1) {
                // create an instance of Model.Edge for next edge
                Edge nextEdge = new Edge();
                nextEdge = edgeArray[index++];

                int nextSource = findSetOfElement(subsetArray, nextEdge.source);
                int nextDestination = findSetOfElement(subsetArray, nextEdge.destination);

                //if the edge doesn't create cycle after including it, we add it in the result and increment the index
                if (nextSource != nextDestination) {
                    finalResult[newEdge++] = nextEdge;
                    performUnion(subsetArray, nextSource, nextDestination);
                }
            }
            for (index = 0; index < newEdge; ++index)
                System.out.println(finalResult[index].source + " - " + finalResult[index].destination + ": " + finalResult[index].weight);
        }

        // create findSetOfElement() method to get set of an element
        int findSetOfElement(Subset subsetArray[], int i) {
            if (subsetArray[i].parent != i)
                subsetArray[i].parent = findSetOfElement(subsetArray, subsetArray[i].parent);
            return subsetArray[i].parent;
        }

        // create performUnion() method to perform union of two sets
        void performUnion(Subset subsetArray[], int sourceRoot, int destinationRoot) {

            int nextSourceRoot = findSetOfElement(subsetArray, sourceRoot);
            int nextDestinationRoot = findSetOfElement(subsetArray, destinationRoot);

            if (subsetArray[nextSourceRoot].value < subsetArray[nextDestinationRoot].value)
                subsetArray[nextSourceRoot].parent = nextDestinationRoot;
            else if (subsetArray[nextSourceRoot].value > subsetArray[nextDestinationRoot].value)
                subsetArray[nextDestinationRoot].parent = nextSourceRoot;
            else {
                subsetArray[nextDestinationRoot].parent = nextSourceRoot;
                subsetArray[nextSourceRoot].value++;
            }
        }


    }
    // Dijkstra's Algorithm
    public void dijkstra(List<List<Node> > adj, int src)
    {
        this.adj = adj;

        for (int i = 0; i < V; i++)
            dist[i] = Integer.MAX_VALUE;

        // Add source node to the priority queue
        pq.add(new Node(src, 0));

        // Distance to the source is 0
        dist[src] = 0 ;

        while (settled.size() != V) {

            // Terminating condition check when
            // the priority queue is empty, return
            if (pq.isEmpty())
                return;

            // Removing the minimum distance node
            // from the priority queue
            int u = pq.remove().node;

            // Adding the node whose distance is
            // finalized
            if (settled.contains(u))

                // Continue keyword skips execution for
                // following check
                continue;

            // We don't have to call e_Neighbors(u)
            // if u is already present in the settled set.
            settled.add(u);

            e_Neighbours(u);
        }
    }

    // Method 2
    // To process all the neighbours
    // of the passed node
    private void e_Neighbours(int u)
    {

        int edgeDistance = -1;
        int newDistance = -1;

        // All the neighbors of v
        for (int i = 0; i < adj.get(u).size(); i++) {
            Node v = adj.get(u).get(i);

            // If current node hasn't already been processed
            if (!settled.contains(v.node)) {
                edgeDistance = v.cost;
                newDistance = dist[u] + edgeDistance;

                // If new distance is cheaper in cost
                if (newDistance < dist[v.node])
                    dist[v.node] = newDistance;

                // Add the current node to the queue
                pq.add(new Node(v.node, dist[v.node]));
            }
        }
    }


    void BFS(int root_node,List<List<Node> > adj_list , int V )   {
        // initially all vertices are not visited
        boolean visited[] = new boolean[V];

        // BFS queue
        LinkedList<Integer> queue = new LinkedList<Integer>();

        // current node = visited, insert into queue
        visited[root_node]=true;
        queue.add(root_node);

        while (queue.size() != 0)  {
            // deque an entry from queue and process it
            root_node = queue.poll();
            System.out.print(root_node+" ");

            // get all adjacent nodes of current node and process
            Iterator<Integer> i = adj_list[root_node].listIterator();
            while (i.hasNext()){
                int n = i.next();
                if (!visited[n]) {
                    visited[n] = true;
                    queue.add(n);
                }
            }
        }
    }





}

