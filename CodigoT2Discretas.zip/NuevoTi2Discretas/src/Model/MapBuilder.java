package Model;

public class MapBuilder {

    private static final Graph instance = new Graph();

    private MapBuilder() {

    }

    public static Graph getGraph() {

        Node planet1 = new Node("planet 1");

        Node planet2 = new Node("planet2");

        Node planet3 = new Node("planet3");

        Node planet4 = new Node("planet4");

        Node planet5 = new Node("planet5");

        Node planet6 = new Node("planet6");

        planet1.addEdge(new Edge(planet1, planet2, 100));

        planet1.addEdge(new Edge(planet1, planet3, 90));

        planet2.addEdge(new Edge(planet2, planet4, 350));

        planet2.addEdge(new Edge(planet2, planet3, 150));

        planet2.addEdge(new Edge(planet2, planet5, 340));

        planet2.addEdge(new Edge(planet2, planet1, 100));

        planet3.addEdge(new Edge(planet3, planet1, 90));

        planet3.addEdge(new Edge(planet3, planet4, 100));

        planet4.addEdge(new Edge(planet4, planet5, 20));

        planet4.addEdge(new Edge(planet4, planet2, 350));

        instance.addNode(planet1);

        instance.addNode(planet2);

        instance.addNode(planet3);

        instance.addNode(planet4);

        instance.addNode(planet6);

        instance.addNode(planet5);

        return instance;

    }

}
