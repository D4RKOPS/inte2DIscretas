package Model;

import java.util.ArrayList;

import java.util.List;



public class Node {

    private String planet;

    private List adjacents = new ArrayList();

    public Node(String planet) {

        this.planet = planet;

    }

    public void addEdge(Edge edge) {

        adjacents.add(edge);

    }

    public List getAdjacents() {

        return adjacents;

    }

    public String getPlanet() {

        return planet;

    }

    @Override

    public String toString() {

        return "Model.Node [planet=" + planet + ", adjacents=" + adjacents + "]";

    }

}
